package single_platoon_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class AUTHORIZE_JOINING_REQUEST{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public AUTHORIZE_JOINING_REQUEST(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(newVehicle) && machine.POSITION.has(Pos) && machine.get_vehicles().has(Vehicle) && !machine.get_platoon().has(newVehicle) && machine.get_platoon().has(Vehicle) && machine.get_j_requests().has(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle)) && !machine.get_leader().equals(BSet.EMPTY)); */
	public /*@ pure */ boolean guard_AUTHORIZE_JOINING_REQUEST( Integer Pos, Integer Vehicle, Integer newVehicle) {
		return (machine.get_vehicles().has(newVehicle) && machine.POSITION.has(Pos) && machine.get_vehicles().has(Vehicle) && !machine.get_platoon().has(newVehicle) && machine.get_platoon().has(Vehicle) && machine.get_j_requests().has(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle)) && !machine.get_leader().equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_AUTHORIZE_JOINING_REQUEST(Pos,Vehicle,newVehicle);
		assignable machine.j_requests, machine.j_authorized;
		ensures guard_AUTHORIZE_JOINING_REQUEST(Pos,Vehicle,newVehicle) &&  machine.get_j_requests().equals(\old(machine.get_j_requests().difference(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle))))) &&  machine.get_j_authorized().equals(\old((machine.get_j_authorized().union(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle)))))); 
	 also
		requires !guard_AUTHORIZE_JOINING_REQUEST(Pos,Vehicle,newVehicle);
		assignable \nothing;
		ensures true; */
	public void run_AUTHORIZE_JOINING_REQUEST( Integer Pos, Integer Vehicle, Integer newVehicle){
		if(guard_AUTHORIZE_JOINING_REQUEST(Pos,Vehicle,newVehicle)) {
			BRelation<Pair<Integer,Integer>,Integer> j_requests_tmp = machine.get_j_requests();
			BRelation<Pair<Integer,Integer>,Integer> j_authorized_tmp = machine.get_j_authorized();

			machine.set_j_requests(j_requests_tmp.difference(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle))));
			machine.set_j_authorized((j_authorized_tmp.union(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle)))));

			System.out.println("AUTHORIZE_JOINING_REQUEST executed Pos: " + Pos + " Vehicle: " + Vehicle + " newVehicle: " + newVehicle + " ");
		}
	}

}
