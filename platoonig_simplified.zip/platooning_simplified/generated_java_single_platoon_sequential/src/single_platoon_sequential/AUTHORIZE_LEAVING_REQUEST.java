package single_platoon_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class AUTHORIZE_LEAVING_REQUEST{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public AUTHORIZE_LEAVING_REQUEST(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle) && machine.get_l_requests().has(Vehicle) && !machine.get_platoon().difference(new BSet<Integer>(Vehicle)).equals(BSet.EMPTY) && !machine.get_leader().equals(BSet.EMPTY) && !machine.get_leader().has(Vehicle)); */
	public /*@ pure */ boolean guard_AUTHORIZE_LEAVING_REQUEST( Integer Vehicle) {
		return (machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle) && machine.get_l_requests().has(Vehicle) && !machine.get_platoon().difference(new BSet<Integer>(Vehicle)).equals(BSet.EMPTY) && !machine.get_leader().equals(BSet.EMPTY) && !machine.get_leader().has(Vehicle));
	}

	/*@ public normal_behavior
		requires guard_AUTHORIZE_LEAVING_REQUEST(Vehicle);
		assignable machine.j_requests, machine.j_authorized, machine.l_requests, machine.l_authorized;
		ensures guard_AUTHORIZE_LEAVING_REQUEST(Vehicle) &&  machine.get_j_requests().equals(\old(machine.get_j_requests().difference(BRelation.cross(BRelation.cross(machine.get_vehicles(),machine.POSITION),new BSet<Integer>(Vehicle))).difference(BRelation.cross(BRelation.cross(new BSet<Integer>(Vehicle),machine.POSITION),machine.get_vehicles())))) &&  machine.get_j_authorized().equals(\old(machine.get_j_authorized().difference(BRelation.cross(BRelation.cross(machine.get_vehicles(),machine.POSITION),new BSet<Integer>(Vehicle))).difference(BRelation.cross(BRelation.cross(new BSet<Integer>(Vehicle),machine.POSITION),machine.get_vehicles())))) &&  machine.get_l_requests().equals(\old(machine.get_l_requests().difference(new BSet<Integer>(Vehicle)))) &&  machine.get_l_authorized().equals(\old((machine.get_l_authorized().union(new BSet<Integer>(Vehicle))))); 
	 also
		requires !guard_AUTHORIZE_LEAVING_REQUEST(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_AUTHORIZE_LEAVING_REQUEST( Integer Vehicle){
		if(guard_AUTHORIZE_LEAVING_REQUEST(Vehicle)) {
			BRelation<Pair<Integer,Integer>,Integer> j_requests_tmp = machine.get_j_requests();
			BRelation<Pair<Integer,Integer>,Integer> j_authorized_tmp = machine.get_j_authorized();
			BSet<Integer> l_requests_tmp = machine.get_l_requests();
			BSet<Integer> l_authorized_tmp = machine.get_l_authorized();

			machine.set_j_requests(j_requests_tmp.difference(BRelation.cross(BRelation.cross(machine.get_vehicles(),machine.POSITION),new BSet<Integer>(Vehicle))).difference(BRelation.cross(BRelation.cross(new BSet<Integer>(Vehicle),machine.POSITION),machine.get_vehicles())));
			machine.set_j_authorized(j_authorized_tmp.difference(BRelation.cross(BRelation.cross(machine.get_vehicles(),machine.POSITION),new BSet<Integer>(Vehicle))).difference(BRelation.cross(BRelation.cross(new BSet<Integer>(Vehicle),machine.POSITION),machine.get_vehicles())));
			machine.set_l_requests(l_requests_tmp.difference(new BSet<Integer>(Vehicle)));
			machine.set_l_authorized((l_authorized_tmp.union(new BSet<Integer>(Vehicle))));

			System.out.println("AUTHORIZE_LEAVING_REQUEST executed Vehicle: " + Vehicle + " ");
		}
	}

}
