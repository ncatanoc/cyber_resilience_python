package single_platoon_sequential;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class platoon{
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;

	LEAVING evt_LEAVING = new LEAVING(this);
	ADD_VEHICLE evt_ADD_VEHICLE = new ADD_VEHICLE(this);
	JOINING_FRONT evt_JOINING_FRONT = new JOINING_FRONT(this);
	CREATE_PLATOON evt_CREATE_PLATOON = new CREATE_PLATOON(this);
	JOINING_FRONT_HEAD evt_JOINING_FRONT_HEAD = new JOINING_FRONT_HEAD(this);
	AUTHORIZE_JOINING_REQUEST evt_AUTHORIZE_JOINING_REQUEST = new AUTHORIZE_JOINING_REQUEST(this);
	JOINING_REAR evt_JOINING_REAR = new JOINING_REAR(this);
	AUTHORIZE_LEAVING_REQUEST evt_AUTHORIZE_LEAVING_REQUEST = new AUTHORIZE_LEAVING_REQUEST(this);
	SET_LEADER evt_SET_LEADER = new SET_LEADER(this);
	JOINING_REAR_TAIL evt_JOINING_REAR_TAIL = new JOINING_REAR_TAIL(this);
	SEND_LEAVING_REQUEST evt_SEND_LEAVING_REQUEST = new SEND_LEAVING_REQUEST(this);
	SEND_JOINING_REQUEST evt_SEND_JOINING_REQUEST = new SEND_JOINING_REQUEST(this);


	/******Set definitions******/
	//@ public static constraint POSITION.equals(\old(POSITION)); 
	public static final BSet<Integer> POSITION = new Enumerated(min_integer,max_integer);

	//@ public static constraint VEHICLES.equals(\old(VEHICLES)); 
	public static final BSet<Integer> VEHICLES = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/
	//@ public static constraint front.equals(\old(front)); 
	public static final Integer front = Test_platoon.random_front;

	//@ public static constraint rear.equals(\old(rear)); 
	public static final Integer rear = Test_platoon.random_rear;



	/******Axiom definitions******/
	/*@ public static invariant BSet.partition(POSITION,new BSet<Integer>(rear),new BSet<Integer>(front)); */


	/******Variable definitions******/
	/*@ spec_public */ private BRelation<Pair<Integer,Integer>,Integer> j_authorized;

	/*@ spec_public */ private BRelation<Pair<Integer,Integer>,Integer> j_requests;

	/*@ spec_public */ private BSet<Integer> l_authorized;

	/*@ spec_public */ private BSet<Integer> l_requests;

	/*@ spec_public */ private BSet<Integer> leader;

	/*@ spec_public */ private BRelation<Integer,Integer> next;

	/*@ spec_public */ private BSet<Integer> platoon;

	/*@ spec_public */ private BSet<Integer> vehicles;




	/******Invariant definition******/
	/*@ public invariant
		vehicles.isSubset(VEHICLES) &&
		platoon.isSubset(vehicles) &&
		 next.domain().isSubset(vehicles) && next.range().isSubset(vehicles) && next.isaFunction() && BRelation.cross(vehicles,vehicles).has(next) &&
		leader.isSubset(vehicles) &&
		j_requests.isSubset(BRelation.cross(BRelation.cross(vehicles,POSITION),vehicles)) &&
		j_authorized.isSubset(BRelation.cross(BRelation.cross(vehicles,POSITION),vehicles)) &&
		l_requests.isSubset(vehicles) &&
		l_authorized.isSubset(vehicles); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.next;*/
	public /*@ pure */ BRelation<Integer,Integer> get_next(){
		return this.next;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.next;
	    ensures this.next == next;*/
	public void set_next(BRelation<Integer,Integer> next){
		this.next = next;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.leader;*/
	public /*@ pure */ BSet<Integer> get_leader(){
		return this.leader;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.leader;
	    ensures this.leader == leader;*/
	public void set_leader(BSet<Integer> leader){
		this.leader = leader;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.l_authorized;*/
	public /*@ pure */ BSet<Integer> get_l_authorized(){
		return this.l_authorized;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.l_authorized;
	    ensures this.l_authorized == l_authorized;*/
	public void set_l_authorized(BSet<Integer> l_authorized){
		this.l_authorized = l_authorized;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.j_requests;*/
	public /*@ pure */ BRelation<Pair<Integer,Integer>,Integer> get_j_requests(){
		return this.j_requests;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.j_requests;
	    ensures this.j_requests == j_requests;*/
	public void set_j_requests(BRelation<Pair<Integer,Integer>,Integer> j_requests){
		this.j_requests = j_requests;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.l_requests;*/
	public /*@ pure */ BSet<Integer> get_l_requests(){
		return this.l_requests;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.l_requests;
	    ensures this.l_requests == l_requests;*/
	public void set_l_requests(BSet<Integer> l_requests){
		this.l_requests = l_requests;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.j_authorized;*/
	public /*@ pure */ BRelation<Pair<Integer,Integer>,Integer> get_j_authorized(){
		return this.j_authorized;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.j_authorized;
	    ensures this.j_authorized == j_authorized;*/
	public void set_j_authorized(BRelation<Pair<Integer,Integer>,Integer> j_authorized){
		this.j_authorized = j_authorized;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.vehicles;*/
	public /*@ pure */ BSet<Integer> get_vehicles(){
		return this.vehicles;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.vehicles;
	    ensures this.vehicles == vehicles;*/
	public void set_vehicles(BSet<Integer> vehicles){
		this.vehicles = vehicles;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.platoon;*/
	public /*@ pure */ BSet<Integer> get_platoon(){
		return this.platoon;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.platoon;
	    ensures this.platoon == platoon;*/
	public void set_platoon(BSet<Integer> platoon){
		this.platoon = platoon;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		vehicles.isEmpty() &&
		platoon.isEmpty() &&
		leader.isEmpty() &&
		next.isEmpty() &&
		j_requests.isEmpty() &&
		j_authorized.isEmpty() &&
		l_requests.isEmpty() &&
		l_authorized.isEmpty();*/
	public platoon(){
		vehicles = new BSet<Integer>();
		platoon = new BSet<Integer>();
		leader = new BSet<Integer>();
		next = new BRelation<Integer,Integer>();
		j_requests = new BRelation<Pair<Integer,Integer>,Integer>();
		j_authorized = new BRelation<Pair<Integer,Integer>,Integer>();
		l_requests = new BSet<Integer>();
		l_authorized = new BSet<Integer>();

	}
}