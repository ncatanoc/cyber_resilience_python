package single_platoon_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class JOINING_FRONT{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public JOINING_FRONT(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(newVehicle) && machine.get_vehicles().has(Vehicle) && !machine.get_platoon().has(newVehicle) && machine.get_platoon().has(Vehicle) && machine.get_next().domain().has(Vehicle) && (machine.get_j_requests().intersection(BRelation.cross(BRelation.cross(new BSet<Integer>(newVehicle),machine.POSITION),machine.get_vehicles()))).equals(BSet.EMPTY) && machine.get_j_authorized().has(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,machine.front),Vehicle)) && !machine.get_leader().equals(BSet.EMPTY)); */
	public /*@ pure */ boolean guard_JOINING_FRONT( Integer Vehicle, Integer newVehicle) {
		return (machine.get_vehicles().has(newVehicle) && machine.get_vehicles().has(Vehicle) && !machine.get_platoon().has(newVehicle) && machine.get_platoon().has(Vehicle) && machine.get_next().domain().has(Vehicle) && (machine.get_j_requests().intersection(BRelation.cross(BRelation.cross(new BSet<Integer>(newVehicle),machine.POSITION),machine.get_vehicles()))).equals(BSet.EMPTY) && machine.get_j_authorized().has(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,machine.front),Vehicle)) && !machine.get_leader().equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_JOINING_FRONT(Vehicle,newVehicle);
		assignable machine.platoon, machine.next, machine.j_authorized;
		ensures guard_JOINING_FRONT(Vehicle,newVehicle) &&  machine.get_platoon().equals(\old((machine.get_platoon().union(new BSet<Integer>(newVehicle))))) &&  machine.get_next().equals(\old((machine.get_next().override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(Vehicle,newVehicle)).override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(newVehicle,machine.get_next().apply(Vehicle)))))))) &&  machine.get_j_authorized().equals(\old(machine.get_j_authorized().difference(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,machine.front),Vehicle))))); 
	 also
		requires !guard_JOINING_FRONT(Vehicle,newVehicle);
		assignable \nothing;
		ensures true; */
	public void run_JOINING_FRONT( Integer Vehicle, Integer newVehicle){
		if(guard_JOINING_FRONT(Vehicle,newVehicle)) {
			BSet<Integer> platoon_tmp = machine.get_platoon();
			BRelation<Integer,Integer> next_tmp = machine.get_next();
			BRelation<Pair<Integer,Integer>,Integer> j_authorized_tmp = machine.get_j_authorized();

			machine.set_platoon((platoon_tmp.union(new BSet<Integer>(newVehicle))));
			machine.set_next((next_tmp.override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(Vehicle,newVehicle)).override(new BRelation<Integer,Integer>(new Pair<Integer,Integer>(newVehicle,next_tmp.apply(Vehicle)))))));
			machine.set_j_authorized(j_authorized_tmp.difference(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,machine.front),Vehicle))));

			System.out.println("JOINING_FRONT executed Vehicle: " + Vehicle + " newVehicle: " + newVehicle + " ");
		}
	}

}
