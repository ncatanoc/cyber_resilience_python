package single_platoon_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class CREATE_PLATOON{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public CREATE_PLATOON(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(Vehicle) && machine.get_platoon().equals(BSet.EMPTY)); */
	public /*@ pure */ boolean guard_CREATE_PLATOON( Integer Vehicle) {
		return (machine.get_vehicles().has(Vehicle) && machine.get_platoon().equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_CREATE_PLATOON(Vehicle);
		assignable machine.platoon, machine.leader;
		ensures guard_CREATE_PLATOON(Vehicle) &&  machine.get_platoon().equals(\old((machine.get_platoon().union(new BSet<Integer>(Vehicle))))) &&  machine.get_leader().equals(\old(new BSet<Integer>(Vehicle))); 
	 also
		requires !guard_CREATE_PLATOON(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_CREATE_PLATOON( Integer Vehicle){
		if(guard_CREATE_PLATOON(Vehicle)) {
			BSet<Integer> platoon_tmp = machine.get_platoon();
			BSet<Integer> leader_tmp = machine.get_leader();

			machine.set_platoon((platoon_tmp.union(new BSet<Integer>(Vehicle))));
			machine.set_leader(new BSet<Integer>(Vehicle));

			System.out.println("CREATE_PLATOON executed Vehicle: " + Vehicle + " ");
		}
	}

}
