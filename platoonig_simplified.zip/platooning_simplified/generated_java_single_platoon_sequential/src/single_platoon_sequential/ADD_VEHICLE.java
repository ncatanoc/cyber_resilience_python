package single_platoon_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class ADD_VEHICLE{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public ADD_VEHICLE(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> machine.VEHICLES.difference(machine.get_vehicles()).has(Vehicle); */
	public /*@ pure */ boolean guard_ADD_VEHICLE( Integer Vehicle) {
		return machine.VEHICLES.difference(machine.get_vehicles()).has(Vehicle);
	}

	/*@ public normal_behavior
		requires guard_ADD_VEHICLE(Vehicle);
		assignable machine.vehicles;
		ensures guard_ADD_VEHICLE(Vehicle) &&  machine.get_vehicles().equals(\old((machine.get_vehicles().union(new BSet<Integer>(Vehicle))))); 
	 also
		requires !guard_ADD_VEHICLE(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_ADD_VEHICLE( Integer Vehicle){
		if(guard_ADD_VEHICLE(Vehicle)) {
			BSet<Integer> vehicles_tmp = machine.get_vehicles();

			machine.set_vehicles((vehicles_tmp.union(new BSet<Integer>(Vehicle))));

			System.out.println("ADD_VEHICLE executed Vehicle: " + Vehicle + " ");
		}
	}

}
