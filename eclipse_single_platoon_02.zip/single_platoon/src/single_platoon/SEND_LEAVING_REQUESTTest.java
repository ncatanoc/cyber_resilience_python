package single_platoon;

import static org.junit.Assert.*;

import org.junit.*;

import eventb_prelude.Pair;

public class SEND_LEAVING_REQUESTTest {
	private platoon machine;
	
	@Before
	public void setUp() {
		machine = new platoon();	
	}

    @After
    public void tearDown() {
    	//
    }
    
    /*
    after send_leaving_request executed
 	( 
	always authorize_leaving_request enabled
		unless leaving executed
  	)
     */
    @Test
    public void SEND_LEAVINGING_REQUEST_test_inv3() {
    	Integer Vehicle = 0;
    	Integer newVehicle = 1;
    	Integer VehicleLeader = 2;
    	// adding Vehicle, newVehicle, and VehicleLeader to the set of vehicles
    	ADD_VEHICLE av = new ADD_VEHICLE(machine);
    	assertTrue(av.guard_ADD_VEHICLE(Vehicle));
    	av.run_ADD_VEHICLE(Vehicle);
    	assertTrue(machine.get_vehicles().has(Vehicle));
    	assertTrue(av.guard_ADD_VEHICLE(newVehicle));
    	av.run_ADD_VEHICLE(newVehicle);
    	assertTrue(machine.get_vehicles().has(newVehicle));
    	assertTrue(av.guard_ADD_VEHICLE(VehicleLeader));
    	av.run_ADD_VEHICLE(VehicleLeader);
    	assertTrue(machine.get_vehicles().has(VehicleLeader));
    	// none of the above vehicles are still part of the platoon
    	assertTrue(machine.get_platoon().isEmpty());
    	// adding VehicleLeader to the platoon 
    	// and making it the VehicleLeader
    	CREATE_PLATOON cp = new CREATE_PLATOON(machine);
    	assertTrue(cp.guard_CREATE_PLATOON(VehicleLeader));
    	cp.run_CREATE_PLATOON(VehicleLeader);
    	assertTrue(machine.get_platoon().has(VehicleLeader));
    	assertTrue(machine.get_leader().has(VehicleLeader));
    	// checking if the request was placed
    	SEND_JOINING_REQUEST s = new SEND_JOINING_REQUEST(machine);
    	assertTrue(s.guard_SEND_JOINING_REQUEST(platoon.rear, VehicleLeader, newVehicle));
    	s.run_SEND_JOINING_REQUEST(platoon.rear, VehicleLeader, newVehicle);
    	assertTrue(machine.get_j_requests().has(new Pair<Integer,Integer>(newVehicle,platoon.rear),VehicleLeader));
    	//
    	AUTHORIZE_JOINING_REQUEST ajr = new AUTHORIZE_JOINING_REQUEST(machine);
    	assertTrue(ajr.guard_AUTHORIZE_JOINING_REQUEST(platoon.rear, VehicleLeader, newVehicle));
    	ajr.run_AUTHORIZE_JOINING_REQUEST(platoon.rear, VehicleLeader, newVehicle);		
    	assertTrue(machine.get_j_authorized().has(new Pair<Integer,Integer>(newVehicle,platoon.rear),VehicleLeader));
    	assertFalse(machine.get_j_requests().has(new Pair<Integer,Integer>(newVehicle,platoon.rear),VehicleLeader));
    	//
    	JOINING_REAR_TAIL jrt = new JOINING_REAR_TAIL(machine);
    	assertTrue(jrt.guard_JOINING_REAR_TAIL(VehicleLeader, newVehicle));
    	jrt.run_JOINING_REAR_TAIL(VehicleLeader, newVehicle);
    	assertTrue(machine.get_platoon().has(newVehicle));
    	assertTrue(machine.get_next().has(new Pair<Integer,Integer>(newVehicle,VehicleLeader)));
    	//
    	assertFalse(machine.get_j_authorized().has(new Pair<Integer,Integer>(newVehicle,platoon.rear),VehicleLeader));
    	// this part is inv_2
    	assertFalse(ajr.guard_AUTHORIZE_JOINING_REQUEST(platoon.rear, VehicleLeader, newVehicle));
    	// the two parts above are inv1 and inv2

    	/*
        after send_leaving_request executed
     	( 
    	always authorize_leaving_request enabled
    		unless leaving executed
      	)
         */
    	SEND_LEAVING_REQUEST slr = new SEND_LEAVING_REQUEST(machine);
    	
    	assertTrue(slr.guard_SEND_LEAVING_REQUEST(newVehicle));
    	slr.run_SEND_LEAVING_REQUEST(newVehicle);
    	assertTrue(machine.get_l_requests().has(newVehicle));
    			
    	//
    	AUTHORIZE_LEAVING_REQUEST alr = new AUTHORIZE_LEAVING_REQUEST(machine);
    	assertTrue(alr.guard_AUTHORIZE_LEAVING_REQUEST(newVehicle));
    	alr.run_AUTHORIZE_LEAVING_REQUEST(newVehicle);
    	//
    	LEAVING l = new LEAVING(machine);
    	assertTrue(l.guard_LEAVING(newVehicle));
    	l.run_LEAVING(newVehicle);
    	//
    	assertFalse(alr.guard_AUTHORIZE_LEAVING_REQUEST(newVehicle));
    }
 
    
}
