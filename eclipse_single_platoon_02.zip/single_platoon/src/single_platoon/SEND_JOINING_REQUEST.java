package single_platoon;


import eventb_prelude.*;
import Util.Utilities;

public class SEND_JOINING_REQUEST{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public SEND_JOINING_REQUEST(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(newVehicle) && machine.POSITION.has(Pos) && machine.get_vehicles().has(Vehicle) && !machine.get_platoon().has(newVehicle) && machine.get_platoon().has(Vehicle) && (machine.get_j_requests().intersection(BRelation.cross(BRelation.cross(new BSet<Integer>(newVehicle),machine.POSITION),machine.get_vehicles()))).equals(BSet.EMPTY) && !machine.get_leader().equals(BSet.EMPTY)); */
	public /*@ pure */ boolean guard_SEND_JOINING_REQUEST( Integer Pos, Integer Vehicle, Integer newVehicle) {
		return (machine.get_vehicles().has(newVehicle) && machine.POSITION.has(Pos) && machine.get_vehicles().has(Vehicle) && !machine.get_platoon().has(newVehicle) && machine.get_platoon().has(Vehicle) && (machine.get_j_requests().intersection(BRelation.cross(BRelation.cross(new BSet<Integer>(newVehicle),machine.POSITION),machine.get_vehicles()))).equals(BSet.EMPTY) && !machine.get_leader().equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_SEND_JOINING_REQUEST(Pos,Vehicle,newVehicle);
		assignable machine.j_requests;
		ensures guard_SEND_JOINING_REQUEST(Pos,Vehicle,newVehicle) &&  machine.get_j_requests().equals(\old((machine.get_j_requests().union(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle)))))); 
	 also
		requires !guard_SEND_JOINING_REQUEST(Pos,Vehicle,newVehicle);
		assignable \nothing;
		ensures true; */
	public void run_SEND_JOINING_REQUEST( Integer Pos, Integer Vehicle, Integer newVehicle){
		if(guard_SEND_JOINING_REQUEST(Pos,Vehicle,newVehicle)) {
			BRelation<Pair<Integer,Integer>,Integer> j_requests_tmp = machine.get_j_requests();

			machine.set_j_requests((j_requests_tmp.union(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(newVehicle,Pos),Vehicle)))));

			System.out.println("SEND_JOINING_REQUEST executed Pos: " + Pos + " Vehicle: " + Vehicle + " newVehicle: " + newVehicle + " ");
		}
	}

}
