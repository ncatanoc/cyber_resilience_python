package single_platoon;

import static org.junit.Assert.*;

import org.junit.*;

import eventb_prelude.Pair;

public class SEND_JOINING_REQUESTTest {
	private platoon machine;
	
	@Before
	public void setUp() {
		machine = new platoon();	
	}

    @After
    public void tearDown() {
    	//
    }
    
    /*
    after send_joining_request executed
 	( 
	 always authorize_joining_request enabled
		unless joining_after executed
  	)
     */
    @Test
    public void SEND_JOINING_REQUEST_test01() {
    	Integer Vehicle = 1, Leader = 2;

    	ADD_VEHICLE av = new ADD_VEHICLE(machine);
    	assertTrue(av.guard_ADD_VEHICLE(Vehicle));
    	av.run_ADD_VEHICLE(Vehicle);
    	// checking that Vehicle is in the set of vehicles
    	assertTrue(machine.get_vehicles().has(Vehicle));
    	assertTrue(av.guard_ADD_VEHICLE(Leader));
    	av.run_ADD_VEHICLE(Leader);
    	assertTrue(machine.get_vehicles().has(Leader));
    	// none of Vehicle, Vehicle, or Leader is part of the platoon
    	assertTrue(machine.get_platoon().isEmpty());
    	CREATE_PLATOON cp = new CREATE_PLATOON(machine);
    	assertTrue(cp.guard_CREATE_PLATOON(Leader));
    	cp.run_CREATE_PLATOON(Leader);
    	// the platoon just has the Leader
    	assertTrue(machine.get_platoon().has(Leader));
    	assertTrue(machine.get_leader().has(Leader));
    	// after SEND_JOINING_REQUEST executed
    	SEND_JOINING_REQUEST s = new SEND_JOINING_REQUEST(machine);
    	assertTrue(s.guard_SEND_JOINING_REQUEST(platoon.rear, Leader, Vehicle));
    	s.run_SEND_JOINING_REQUEST(platoon.rear, Leader, Vehicle);
    	assertTrue(machine.get_j_requests().has(new Pair<Integer,Integer>(Vehicle,platoon.rear),Leader));
    	// always AUTHORIZE_JOINING_REQUEST enabled
    	AUTHORIZE_JOINING_REQUEST ajr = new AUTHORIZE_JOINING_REQUEST(machine);
    	assertTrue(ajr.guard_AUTHORIZE_JOINING_REQUEST(platoon.rear, Leader, Vehicle));
    	ajr.run_AUTHORIZE_JOINING_REQUEST(platoon.rear, Leader, Vehicle);		
    	assertTrue(machine.get_j_authorized().has(new Pair<Integer,Integer>(Vehicle,platoon.rear),Leader));
    	assertFalse(machine.get_j_requests().has(new Pair<Integer,Integer>(Vehicle,platoon.rear),Leader));
    	// unless JOINING_REAR_TAIL executed
    	JOINING_REAR_TAIL jrt = new JOINING_REAR_TAIL(machine);
    	assertTrue(jrt.guard_JOINING_REAR_TAIL(Leader, Vehicle));
    	jrt.run_JOINING_REAR_TAIL(Leader, Vehicle);
    	// Vehicle belongs in the platoon
    	assertTrue(machine.get_platoon().has(Vehicle));
    	// Vehicle is right behind the Leader
    	assertTrue(machine.get_next().has(new Pair<Integer,Integer>(Vehicle,Leader)));
    	// Vehicle is no longer part of AUTHORIZE_JOINING_REQUEST's queue
    	assertFalse(machine.get_j_authorized().has(new Pair<Integer,Integer>(Vehicle,platoon.rear),Leader));
    	assertFalse(ajr.guard_AUTHORIZE_JOINING_REQUEST(platoon.rear, Leader, Vehicle));
    }
 
    
}
