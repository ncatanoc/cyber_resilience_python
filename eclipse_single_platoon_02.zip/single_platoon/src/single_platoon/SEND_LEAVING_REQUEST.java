package single_platoon;


import eventb_prelude.*;
import Util.Utilities;

public class SEND_LEAVING_REQUEST{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public SEND_LEAVING_REQUEST(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle) && !machine.get_leader().equals(BSet.EMPTY) && !machine.get_leader().has(Vehicle)); */
	public /*@ pure */ boolean guard_SEND_LEAVING_REQUEST( Integer Vehicle) {
		return (machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle) && !machine.get_leader().equals(BSet.EMPTY) && !machine.get_leader().has(Vehicle));
	}

	/*@ public normal_behavior
		requires guard_SEND_LEAVING_REQUEST(Vehicle);
		assignable machine.l_requests;
		ensures guard_SEND_LEAVING_REQUEST(Vehicle) &&  machine.get_l_requests().equals(\old((machine.get_l_requests().union(new BSet<Integer>(Vehicle))))); 
	 also
		requires !guard_SEND_LEAVING_REQUEST(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_SEND_LEAVING_REQUEST( Integer Vehicle){
		if(guard_SEND_LEAVING_REQUEST(Vehicle)) {
			BSet<Integer> l_requests_tmp = machine.get_l_requests();

			machine.set_l_requests((l_requests_tmp.union(new BSet<Integer>(Vehicle))));

			System.out.println("SEND_LEAVING_REQUEST executed Vehicle: " + Vehicle + " ");
		}
	}

}
