package single_platoon;

import eventb_prelude.*;
import Util.Utilities;

public class LEAVING{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public LEAVING(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle) && machine.get_l_authorized().has(Vehicle) && !machine.get_platoon().difference(new BSet<Integer>(Vehicle)).equals(BSet.EMPTY) && !machine.get_leader().equals(BSet.EMPTY) && !machine.get_leader().has(Vehicle)); */
	public /*@ pure */ boolean guard_LEAVING( Integer Vehicle) {
		return (machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle) && machine.get_l_authorized().has(Vehicle) && !machine.get_platoon().difference(new BSet<Integer>(Vehicle)).equals(BSet.EMPTY) && !machine.get_leader().equals(BSet.EMPTY) && !machine.get_leader().has(Vehicle));
	}

	/*@ public normal_behavior
		requires guard_LEAVING(Vehicle);
		assignable machine.platoon, machine.next, machine.l_authorized;
		ensures guard_LEAVING(Vehicle) &&  machine.get_platoon().equals(\old(machine.get_platoon().difference(new BSet<Integer>(Vehicle)))) &&  machine.get_next().equals(\old((machine.get_next().domainSubtraction(new BSet<Integer>(Vehicle)).rangeSubtraction(new BSet<Integer>(Vehicle)).union(BRelation.cross(machine.get_next().inverse().image(new BSet<Integer>(Vehicle)),machine.get_next().image(machine.get_next().inverse().image(new BSet<Integer>(Vehicle)))))))) &&  machine.get_l_authorized().equals(\old(machine.get_l_authorized().difference(new BSet<Integer>(Vehicle)))); 
	 also
		requires !guard_LEAVING(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_LEAVING( Integer Vehicle){
		if(guard_LEAVING(Vehicle)) {
			BSet<Integer> platoon_tmp = machine.get_platoon();
			BRelation<Integer,Integer> next_tmp = machine.get_next();
			BSet<Integer> l_authorized_tmp = machine.get_l_authorized();

			machine.set_platoon(platoon_tmp.difference(new BSet<Integer>(Vehicle)));
			machine.set_next((next_tmp.domainSubtraction(new BSet<Integer>(Vehicle)).rangeSubtraction(new BSet<Integer>(Vehicle)).union(BRelation.cross(next_tmp.inverse().image(new BSet<Integer>(Vehicle)),next_tmp.image(next_tmp.inverse().image(new BSet<Integer>(Vehicle)))))));
			machine.set_l_authorized(l_authorized_tmp.difference(new BSet<Integer>(Vehicle)));

			System.out.println("LEAVING executed Vehicle: " + Vehicle + " ");
		}
	}

}
