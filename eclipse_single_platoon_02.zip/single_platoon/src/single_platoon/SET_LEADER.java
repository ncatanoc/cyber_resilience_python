package single_platoon;


import eventb_prelude.*;
import Util.Utilities;

public class SET_LEADER{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public SET_LEADER(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle); */
	public /*@ pure */ boolean guard_SET_LEADER( Integer Vehicle) {
		return machine.get_vehicles().has(Vehicle) && machine.get_platoon().has(Vehicle);
	}

	/*@ public normal_behavior
		requires guard_SET_LEADER(Vehicle);
		assignable machine.leader;
		ensures guard_SET_LEADER(Vehicle) &&  machine.get_leader().equals(\old(new BSet<Integer>(Vehicle))); 
	 also
		requires !guard_SET_LEADER(Vehicle);
		assignable \nothing;
		ensures true; */
	public void run_SET_LEADER( Integer Vehicle){
		if(guard_SET_LEADER(Vehicle)) {
			BSet<Integer> leader_tmp = machine.get_leader();

			machine.set_leader(new BSet<Integer>(Vehicle));

			System.out.println("SET_LEADER executed Vehicle: " + Vehicle + " ");
		}
	}

}
