package single_platoon;

import eventb_prelude.*;
import Util.Utilities;

public class CREATE_PLATOON{
	/*@ spec_public */ private platoon machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public CREATE_PLATOON(platoon m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_vehicles().has(newVehicle) && machine.get_platoon().equals(BSet.EMPTY)); */
	public /*@ pure */ boolean guard_CREATE_PLATOON( Integer newVehicle) {
		return (machine.get_vehicles().has(newVehicle) && machine.get_platoon().equals(BSet.EMPTY));
	}

	/*@ public normal_behavior
		requires guard_CREATE_PLATOON(newVehicle);
		assignable machine.platoon, machine.leader;
		ensures guard_CREATE_PLATOON(newVehicle) &&  machine.get_platoon().equals(\old((machine.get_platoon().union(new BSet<Integer>(newVehicle))))) &&  machine.get_leader().equals(\old(new BSet<Integer>(newVehicle))); 
	 also
		requires !guard_CREATE_PLATOON(newVehicle);
		assignable \nothing;
		ensures true; */
	public void run_CREATE_PLATOON( Integer newVehicle){
		if(guard_CREATE_PLATOON(newVehicle)) {
			BSet<Integer> platoon_tmp = machine.get_platoon();
			BSet<Integer> leader_tmp = machine.get_leader();

			machine.set_platoon((platoon_tmp.union(new BSet<Integer>(newVehicle))));
			machine.set_leader(new BSet<Integer>(newVehicle));

			System.out.println("CREATE_PLATOON executed newVehicle: " + newVehicle + " ");
		}
	}

}
